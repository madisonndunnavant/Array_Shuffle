﻿//Name: Madison Dunnavant
//Array Shuffle Exercise
//Description: This program will take six integers that the user inputs and will first sort the array, then shuffle the array using the Fisher-Yates algorithm. Once shuffled, the result of the shuffle will be printed. 
using System;


namespace ArrayShuffleExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int[] integersEntered = new int[6];
            int x = integersEntered.Length;

            //This will allow the user to input the numbers that will be stored in the array integersEntered[]
            for (int i = 0; i < integersEntered.Length; i++)
            {
                Console.WriteLine("Please enter a number: ");
               try
                {
                    integersEntered[i] = Int32.Parse(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Please enter a valid integer: ");
                }



            }

            Console.Write("Array before sorting: ");
            foreach( int i in integersEntered)
            {
                Console.Write(i + " ");
            }
            //Array.Sort is a built-in method in .NET. It sorts the elements from smallest to largest.
            Array.Sort(integersEntered);
            Console.WriteLine();
            Console.Write("The array when sorted: ");
            //This foreach statement will print the array after it has been sorted
            foreach(int j in integersEntered) 
            {
                Console.Write(j + " ");
  
            }
            Console.WriteLine();
            Console.Write("The array when shuffled: ");
            //This calls the method ShuffleArray with the values integersEntered and x.
            ShuffleArray(integersEntered, x);

            //This method is a take on the Fisher-Yates algorithm. 
            static void ShuffleArray(int [] shuffle, int val)
            {
                //There is a built-in class named Random. For this, I created a new object for the Random class.
                Random rand = new Random();

                //This for loop begins at the end of the array. It will quickly work its way to the beginning of the array. 
                for (int i = val - 1; i > 0; i--)
                {
                    //y = rand.Next() will randomly choose an index between 0 and i. 
                    int y = rand.Next(0, i + 1);
                    //The next 3 lines of code will take the integer at index i in the shuffle array and store it in the variable temp. Then, index i will become replaced with the integer at index 
                    //y. Lastly, the integer at index y becomes replaced with the integer stored in temp.
                    int temp = shuffle[i];
                    shuffle[i] = shuffle[y];
                    shuffle[y] = temp;
                }
                //This for loop will print the now shuffled array.
                for (int i = 0; i < val; i++)
                {
                    Console.Write(shuffle[i] + " ");
                }
            }
        }
    }
}
